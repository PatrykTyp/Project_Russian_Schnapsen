#pragma once
#include "Card.h"
class Players{

public:
	static Card deck[], stock[];
	static Card player1[], player2[], player3[];
};

