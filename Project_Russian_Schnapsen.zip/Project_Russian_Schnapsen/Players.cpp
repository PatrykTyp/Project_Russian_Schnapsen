#include "Players.h"

Card Players::deck[24];
Card Players::stock[3];
Card Players::player1[9];
Card Players::player2[9];
Card Players::player3[9];