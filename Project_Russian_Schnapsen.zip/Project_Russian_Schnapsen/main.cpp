#include <SFML/Graphics.hpp>

#include "Gra.h"

using namespace std;

int main() {
	Gra game;
	game.start();
	return 0;
}